import chalk from "chalk"; // install via: npm install chalk
import { Sequelize } from "sequelize";

const customLogger = (sql, timing) => {
  const timestamp = new Date().toLocaleTimeString();
  const method = sql.trim().split(" ")[0].toUpperCase();

  console.log(chalk.gray(`[${timestamp}]`), chalk.cyan(`[${method}]`), chalk.white(sql), chalk.green(timing ? `(${timing}ms)` : ""));
};

const sequelize = new Sequelize({
  dialect: "postgres",
  host: "localhost",
  database: "inventory_db",
  username: "postgres",
  password: "postgres",
  port: 5432,
  // logging: customLogger,
  logging: (sql, timing) => {
    console.log(chalk.gray(`[${new Date().toLocaleTimeString()}]`), chalk.cyan(`[SQL]`), chalk.white(sql), chalk.green(timing ? `(${timing}ms)` : ""));
    console.log(chalk.red("Full Error Details:"), sql); // Log full query details
  },
  benchmark: true
});

export default sequelize;
